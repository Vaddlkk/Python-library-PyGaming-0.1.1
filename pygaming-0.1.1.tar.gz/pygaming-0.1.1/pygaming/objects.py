class GameObject:
    def __init__(self, name="Object", x=0.0, y=0.0, z=0.0):
        self.name = name
        self.x = x
        self.y = y
        self.z = z
        self.visible = True
    
    def set_position(self, x, y, z):
        """Установка координат"""
        self.x, self.y, self.z = x, y, z
    
    def move(self, dx, dy, dz):
        """Смещение объекта"""
        self.x += dx
        self.y += dy
        self.z += dz
    
    def get_position(self):
        """Получение текущих координат"""
        return (self.x, self.y, self.z)