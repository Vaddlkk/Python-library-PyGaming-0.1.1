import pygame

class Engine:
    def __init__(self, width=800, height=600, title="Pygaming Engine"):
        """Инициализация движка"""
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.objects = []
    
    def add_object(self, obj):
        """Добавление объекта на сцену"""
        self.objects.append(obj)
    
    def render(self):
        """Отрисовка всех объектов"""
        self.screen.fill((0, 0, 0))
        for obj in self.objects:
            if obj.visible:
                # Простейший 2D-рендеринг
                x = int(obj.x * 50 + 400)
                y = int(obj.y * 50 + 300)
                pygame.draw.circle(self.screen, (255, 0, 0), (x, y), 10)
        pygame.display.flip()
    
    def run(self, fps=60):
        """Запуск основного цикла"""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            
            self.render()
            self.clock.tick(fps)
        pygame.quit()