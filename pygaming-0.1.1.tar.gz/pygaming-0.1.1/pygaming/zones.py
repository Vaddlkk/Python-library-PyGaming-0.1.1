class Zone:
    def __init__(self, x1, y1, z1, x2, y2, z2):
        self.min = (min(x1, x2), min(y1, y2), min(z1, z2))
        self.max = (max(x1, x2), max(y1, y2), max(z1, z2))
    
    def contains(self, obj):
        """Проверка, находится ли объект в зоне"""
        return (self.min[0] <= obj.x <= self.max[0] and
                self.min[1] <= obj.y <= self.max[1] and
                self.min[2] <= obj.z <= self.max[2])