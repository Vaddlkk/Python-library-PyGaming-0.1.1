# Pygaming v0.1.1

Простой игровой движок для Python с поддержкой 2D/3D объектов и зон.

## Установка
```bash
pip install pygaming